<?php
ini_set('display_errors', 0);
session_start();
include 'server.php';
ob_start(); // Start output buffering
if(isset($_SESSION['user'])){
// Set a cookie if form is submitted
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['room'])) {
    $cookie_name = "class";
    $cookie_value = $_POST["room"];
    setcookie($cookie_name, $cookie_value, time() + (86400 * 30), "/");
    $room = $_POST["room"];
}else{

    $room = $_COOKIE["class"] ;
}

ob_end_flush(); // Flush the output buffer and send output
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Filter Students</title>
    <style>
        input{
            width: 100%;
    padding: 5px;
    border: 0px;
    border-radius: 10px;
        }
        * {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif;
        }

        body {
            display: flex;
            flex-direction: column;
            justify-content: flex-start;
            align-items: center;
            min-height: 100vh;
            background-color: #f5f5f7;
        }

    
        .tab-container {
            display: flex;
    border-radius: 20px;
    width: 100%;
    /* max-width: 500px; */
    /* align-items: center; */
    align-content: space-between;
    justify-content: space-between;
    flex-wrap: nowrap;
    flex-direction: row;
    margin-top: 10px;
        }
        
        .profile{
            width: 100%;
    display: flex;
    /* padding: 10px 20px; */
    text-align: center;

   
    text-decoration: none;
    color: #333;
    flex-direction: column;
    align-content: center;
    align-items: center;}
    a{
        text-decoration: none;
        color:#000;
    }
        .tab {
            width: 100%;
            
            padding: 10px 20px;
            text-align: center;
            cursor: pointer;
            border: 1px solid #ccc;
            border-bottom: none;
            border-radius: 20px;
            background-color: #f2f2f2;
            text-decoration: none;
            color: #333;
        }

        .tab_active {
            width: 100%;
    padding: 10px;
    border-radius: 20px;
    background-color: #fff;
    color: #000;
    font-size: 16px;
    cursor: pointer;
    
        }

        .container {
            background: #ffffff;
            padding: 20px 30px;
            border-radius: 12px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            max-width: 810px;
            width: 100%;
        }

        .table-container {
            width: 100%;
            overflow-x: auto;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }

        th, td {
            border: 1px solid #ccc;
            padding: 10px;
            text-align: left;
        }
        input
        th {
            background-color: #f2f2f2;
            width: 100%;
        
    }
        .profile_user{
            
            padding-left:10px;
            padding-right:10px;
            width: 100%;
    display: flex;
    flex-direction: row;
    align-items: center;
    align-content: center;
    justify-content: space-between;

        }.logout{
            width: 200px;

        }
        .tab-alin{
            display: flex;
    align-items: center;
    width: 100%;
    max-width:810px;
    padding: 10px;
    flex-direction: column;
     border-radius: 20px;
    border: 1px solid #ccc;
    border-bottom: none;
    background-color: #f2f2f2;

        }
    </style>
</head>
<body>

<div class="profile">
    <div class="tab-alin">
    <div class=profile_user>
    <?php
     echo "<a href='teacher_profile.php'>".$_SESSION['user']."</a>";
    ?><button style=" background:#fff; padding:2px;width:100px;border-radius: 20px;"><a href="logout.php">logout</a></button>
    </div>
<div class="tab-container">
    <?php
    
    if($_SESSION['user_level'] == "admin"){
    
    ?>
    <button class="tab"><a href="behavior_report.php" ><h4>ฟอร์มนักเรียน</h4></a></button>
    <?php
    }
    ?>
    <button class="tab_active"><a href="student_history.php">กรองนักเรียนตามห้อง</a></button>
    </div></div></div>

<div class="container">
    <h2>กรองนักเรียนตามห้อง</h2>
    <!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dropdown Filter</title>
    <script>
        // ข้อมูลห้องเรียนสำหรับแต่ละเกรด
        const gradeRooms = {
            'ม.1': Array.from({ length: 15 }, (_, i) => `ม.1/${i + 1}`),
            'ม.2': Array.from({ length: 15 }, (_, i) => `ม.2/${i + 1}`),
            'ม.3': Array.from({ length: 15 }, (_, i) => `ม.3/${i + 1}`),
            'ม.4': Array.from({ length: 10 }, (_, i) => `ม.4/${i + 1}`),
            'ม.5': Array.from({ length: 10 }, (_, i) => `ม.5/${i + 1}`),
            'ม.6': Array.from({ length: 10 }, (_, i) => `ม.6/${i + 1}`)
        };

        // ฟังก์ชันอัปเดต dropdown ห้องเรียน
        function updateRooms() {
            var grade = document.getElementById("grade").value;
            var roomSelect = document.getElementById("room");
            roomSelect.innerHTML = '';

            if (grade && gradeRooms[grade]) {
                gradeRooms[grade].forEach(room => {
                    var option = document.createElement("option");
                    option.value = room;
                    option.text = room;
                    roomSelect.appendChild(option);
                });
            }
        }
    </script>
    <div style='display: flex;
    justify-content: flex-start;
    flex-direction: row;
    '>
    <form method="POST" action= student_history.php >
    <label for="grade">ปี: </label>
        <select style='margin: 2px 'id="grade" name="grade" onchange="updateRooms()">
            <option value="">เลือกปีการศึกษา</option>
            <option value="ม.1">ม.1</option>
            <option value="ม.2">ม.2</option>
            <option value="ม.3">ม.3</option>
            <option value="ม.4">ม.4</option>
            <option value="ม.5">ม.5</option>
            <option value="ม.6">ม.6</option>
        </select>

        <label for="room">ห้อง:</label>
        <select style='margin-left: 2px ' id="room" name="room">
            <option value="">เลือกห้อง</option>
        </select>
        <button  style='width: 75px; padding-right: 5px; padding-left: 5px;background: #000;color: #fff;border-radius: 10px;' name='student_id' type="submit">กรอง</button>
    </form>
     
        
    </div>
<?php
        if(isset($_COOKIE["class"])){


 
            
            // สร้างคำสั่ง SQL สำหรับกรองข้อมูล
            $sql = "SELECT * FROM students WHERE year_class = '$room'";

            $result = $conn->query($sql);
            
            if ($result->num_rows > 0) {
  
                echo "<h2>รายชื่อนักเรียนในห้อง $room</h2>";
                echo "<div class='table-container'>";
                echo "<table>";
                if($_SESSION['user_level'] == "admin"){
                echo "<tr style='width: 15px'><th>รหัสนักเรียน</th><th>เลขที่</th><th><p style = 'width:90px'>ชื่อ</p></th><th><p style = 'width:90px'>นามสกุล</p></th><th>คะแนน</th><th> profile </th><th> save </th></tr>";
                 }else{echo "<tr style='width: 15px'><th>รหัสนักเรียน</th><th>เลขที่</th><th><p style = 'width:90px'>ชื่อ</p></th><th><p style = 'width:90px'>นามสกุล</p></th><th>คะแนน</th><th> profile </th></tr>";
                 }
                 
                 while ($row = $result->fetch_assoc()) {
                    if($_SESSION['user_level'] == "admin"){
                        echo "<tr>";
                        echo "<td><form action='update_table.php' method='post'><input name='student_number' type='hidden' class='table_in' value='".$row["student_number"]."'>".$row["student_number"]."</td>";
                        echo "<td><input name='class_number' class='table_in' value='".$row["class_number"]."'></td>";
                        echo "<td><input name='first_name' class='table_in' value='".$row["first_name"]."'></td>";
                        echo "<td><input name='last_name' class='table_in' value='".$row["last_name"]."'></td>";
                        echo "<td><input name='score' class='table_in' value='".$row["score"]."'></td>";
                        echo "<td><button style=' padding: 5px;   width: 100%;height: 100%;background: black; color: white;border-radius: 10px;' type='submit'>save</button></form></td>";
                        echo "<td><form method='POST' action='profile.php'><button style='padding: 5px;    width: 100%;height: 100%;background: #fff;color: #000;border-radius: 10px;' name='student_id' value='". $row["student_number"]."'>profile</button></form></td>";
                

                    }else{
                        echo "<tr>";
                        echo "<td><p type='hidden' class='table_in' value='".$row["student_number"]."'>".$row["student_number"]."</td>";
                        echo "<td><p class='table_in' >".$row["class_number"]."</p></td>";
                        echo "<td><p class='table_in' >".$row["first_name"]."</p></td>";
                        echo "<td><p class='table_in' >".$row["last_name"]."</p></td>";
                        echo "<td><p class='table_in' >".$row["score"]."</p></td>";
                        echo "<td><form method='POST' action='profile.php'><button style='padding: 5px;    width: 100%;height: 100%;background: #fff;color: #000;border-radius: 10px;' name='student_id' value='". $row["student_number"]."'>profile</button></form></td>";
                   
                   }
                }
                echo "</table>";
                echo "</div>";
            }else{
                echo "ไม่พบข้อมูลนักเรียนในห้อง $room";
            }
        }
            $conn->close();

        

       
        ?>
    </form>
</div>

</body>
</html>


<?php
}else{

    header("location:login.php");
}
?>