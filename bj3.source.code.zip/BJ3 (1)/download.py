import psycopg2
import pandas as pd

# Connect to your database
conn = psycopg2.connect(
    host='192.168.1.14',  # Only the IP address here
    port='4080',          # Specify the port separately
    user='root',
    password='',
    dbname='bj3'
)

# Write your query
query = "SELECT * FROM teacher"

# Execute the query and fetch the data into a DataFrame
df = pd.read_sql_query(query, conn)

# Export the DataFrame to a CSV file
df.to_csv('output.csv', index=False)

# Close the connection
conn.close()