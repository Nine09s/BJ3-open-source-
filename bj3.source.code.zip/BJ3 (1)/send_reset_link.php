<?php
// สร้างการเชื่อมต่อกับฐานข้อมูล
session_start();
include 'server.php';
$_SESSION['email aleert'] = "";
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = $_POST['email'];
    $token = bin2hex(random_bytes(50)); // สร้างโทเค็นสุ่ม

    // บันทึกโทเค็นและเวลาหมดอายุลงในฐานข้อมูล
    $stmt = $conn->prepare("UPDATE teacher SET reset_token=?, token_expiry=DATE_ADD(NOW(), INTERVAL 1 HOUR) WHERE email=?");
    $stmt->bind_param("ss", $token, $email);
    $stmt->execute();

    if ($stmt->affected_rows > 0) {
        // ส่งอีเมล

 
require 'C:\xampp\email-app\vendor\autoload.php'; // หากคุณติดตั้ง PHPMailer ด้วย Composer

$mail = new PHPMailer(true);

try {
    //Server settings
    $mail->SMTPDebug = 0;                                       // ปิดการดีบัก (0 คือปิด, 2 คือเปิด)
    $mail->isSMTP();                                            // ใช้ SMTP
    $mail->Host       = 'smtp.gmail.com';                       // เซิร์ฟเวอร์ SMTP ของ Gmail
    $mail->SMTPAuth   = true;                                   // เปิดการตรวจสอบสิทธิ์ SMTP
    $mail->Username   = '19887@banhan3.ac.th';                 // <--- เปลี่ยนเป็นอีเมลของคุณ
    $mail->Password   = 'yjbw zaew chys apab';                    // <--- เปลี่ยนเป็น App Password ที่คุณสร้างจาก Google
    $mail->SMTPSecure = 'tls';                                  // เปิดใช้การเข้ารหัส TLS
    $mail->Port       = 587;                                    // พอร์ตที่ใช้สำหรับ TLS

    // ผู้ส่งและผู้รับ
    $mail->setFrom('19887@banhan3.ac.th', 'banhan3.duckdns.org');        // <--- เปลี่ยนเป็นอีเมลของคุณและชื่อที่คุณต้องการแสดง
    $mail->addAddress($email, 'Recipient Name'); // <--- เปลี่ยนเป็นอีเมลของผู้รับและชื่อของผู้รับ

    // เนื้อหาอีเมล
    $mail->isHTML(true);                                        // ตั้งค่าให้ใช้รูปแบบ HTML
    $mail->Subject = 'reset password [banhan3.duckdns.org]';                  // <--- เปลี่ยนหัวข้ออีเมลให้ตรงกับที่คุณต้องการ
    $mail->Body    = "<p>สวัสดี [".$email."],</p><br>

<p>เราได้รับคำขอรีเซ็ตรหัสผ่านสำหรับบัญชีของคุณที่ [banhan3.duckdns.org] หากคุณต้องการรีเซ็ตรหัสผ่านของคุณ, กรุณาคลิกที่ลิงก์ด้านล่าง:</p><br>


<b><a href='http://banhan3.duckdns.org:4080/reset_password.php?token=". $token."'>reset password</a></b><br>

<p>หากคุณไม่ได้ขอรีเซ็ตรหัสผ่านนี้, กรุณาเพิกเฉยข้อความนี้และไม่มีการเปลี่ยนแปลงใดๆ</p><br>

<p>ขอบคุณ,</p><br>
<p>ทีมงาน 6/10 (68) [banhan3.duckdns.org]</p><br>
"; // <--- เปลี่ยนเนื้อหาของอีเมลในรูปแบบ HTML
    $mail->AltBody = 'This is the body in plain text for non-HTML mail clients'; // <--- เปลี่ยนเนื้อหาในรูปแบบ plain text สำหรับลูกค้าที่ไม่รองรับ HTML

    $mail->send();
    $_SESSION['email aleert'] =  'email has been sent';                               // แสดงข้อความเมื่อส่งอีเมลสำเร็จ
} catch (Exception $e) {
    $_SESSION['email aleert'] = "email could not be sent. Mailer Error: {$mail->ErrorInfo}"; // แสดงข้อความเมื่อส่งอีเมลไม่สำเร็จ
}

    } else {
        $_SESSION['email aleert'] = "No account found with that email address.";
    }
}

$stmt->close();
$conn->close();
header("Location: sent_email.php");
?>