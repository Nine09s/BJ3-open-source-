<?php
session_start();
include 'server.php';
$_SESSION['POS_year'] = $_POST['year_class'];
if (isset($_POST['year_class'])) {
    
    $year_class = $_POST['year_class'];

    $sql = "SELECT student_number, first_name, last_name, gender, class_number, score FROM students WHERE year_class = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $year_class);
    $stmt->execute();
    $result = $stmt->get_result();

    $filtered_students = [];
    while ($row = $result->fetch_assoc()) {
        $filtered_students[] = $row;
    }

    $_SESSION['filtered_students'] = $filtered_students;
    echo json_encode($filtered_students);
} else {
    echo json_encode([]);
}
