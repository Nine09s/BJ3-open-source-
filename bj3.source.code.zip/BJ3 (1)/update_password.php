<?php

session_start();
include 'server.php';
echo $_SESSION['reset aleert'] = "";
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $token = $_POST['token'];
    $newPassword = $_POST['password'];

    // ตรวจสอบว่าโทเค็นยังใช้ได้อยู่
    $stmt = $conn->prepare("SELECT email FROM teacher WHERE reset_token=? AND token_expiry > NOW()");
    $stmt->bind_param("s", $token);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        // อัปเดตรหัสผ่านใหม่
        $email = $result->fetch_assoc()['email'];
        $stmt = $conn->prepare("UPDATE teacher SET password=?, reset_token=NULL, token_expiry=NULL WHERE email=?");
        $stmt->bind_param("ss", $newPassword, $email);
        $stmt->execute();
        $_SESSION['email aleert'] = "Password has been reset successfully.";
    } else {
        $_SESSION['email aleert'] ="The link you used has expired.";
        echo "Invalid or expired token.";
    }
}

$stmt->close();
$conn->close();
header("Location: login.php");
?>