<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require 'C:\xampp\email-app\vendor\autoload.php'; // หากคุณติดตั้ง PHPMailer ด้วย Composer

$mail = new PHPMailer(true);

try {
    //Server settings
    $mail->SMTPDebug = 0;                                       // ปิดการดีบัก (0 คือปิด, 2 คือเปิด)
    $mail->isSMTP();                                            // ใช้ SMTP
    $mail->Host       = 'smtp.gmail.com';                       // เซิร์ฟเวอร์ SMTP ของ Gmail
    $mail->SMTPAuth   = true;                                   // เปิดการตรวจสอบสิทธิ์ SMTP
    $mail->Username   = '19887@banhan3.ac.th';                 // <--- เปลี่ยนเป็นอีเมลของคุณ
    $mail->Password   = 'yjbw zaew chys apab';                    // <--- เปลี่ยนเป็น App Password ที่คุณสร้างจาก Google
    $mail->SMTPSecure = 'tls';                                  // เปิดใช้การเข้ารหัส TLS
    $mail->Port       = 587;                                    // พอร์ตที่ใช้สำหรับ TLS

    // ผู้ส่งและผู้รับ
    $mail->setFrom('19887@banhan3.ac.th', 'nsame');        // <--- เปลี่ยนเป็นอีเมลของคุณและชื่อที่คุณต้องการแสดง
    $mail->addAddress('testsup0005@gmail.com', 'Recipient Name'); // <--- เปลี่ยนเป็นอีเมลของผู้รับและชื่อของผู้รับ

    // เนื้อหาอีเมล
    $mail->isHTML(true);                                        // ตั้งค่าให้ใช้รูปแบบ HTML
    $mail->Subject = 'Password Reset Request';                  // <--- เปลี่ยนหัวข้ออีเมลให้ตรงกับที่คุณต้องการ
    $mail->Body    = 'This is the HTML message body <b>in bold!</b>'; // <--- เปลี่ยนเนื้อหาของอีเมลในรูปแบบ HTML
    $mail->AltBody = 'This is the body in plain text for non-HTML mail clients'; // <--- เปลี่ยนเนื้อหาในรูปแบบ plain text สำหรับลูกค้าที่ไม่รองรับ HTML

    $mail->send();
    echo 'Message has been sent';                               // แสดงข้อความเมื่อส่งอีเมลสำเร็จ
} catch (Exception $e) {
    echo "Message could not be sent. Mailer Error: {$mail->ErrorInfo}"; // แสดงข้อความเมื่อส่งอีเมลไม่สำเร็จ
}
?>