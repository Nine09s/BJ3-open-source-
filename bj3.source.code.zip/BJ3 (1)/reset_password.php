<!-- reset_password.php -->
<?php
if (isset($_GET['token'])) {
    $token = $_GET['token'];
    // ตรวจสอบโทเค็นในฐานข้อมูลและตรวจสอบว่าหมดอายุหรือไม่
}
?>
<?php
ini_set('display_errors', 0);
session_start();
if(isset($_SESSION['user'])){

    header ("Location: behavior_report.php");
}else{
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login Page</title>
    <style>
        body {
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 85vh;
            background-color: #e1e1e1;
            font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif;
            color: #333;
        }

        .login-container {
            width: 400px;
            padding: 20px;
            background: #fff;
            margin: 15px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            border-radius: 8px;
        }

        .login-container h1 {
            margin: 0 0 20px;
            font-size: 24px;
            font-weight: 600;
            text-align: center;
        }

        .login-container form {
            display: flex;
            flex-direction: column;
        }

        .login-container input {
            width: calc(100% - 20px);
            padding: 10px;
            margin: 10px 0;
            border: 1px solid #ddd;
            border-radius: 4px;
            font-size: 16px;
        }

        .login-container button {
            width: 100%;
    padding: 10px;
    margin: 10px 0;
    border: none;
    border-radius: 4px;
    background-color: #000;
    color: white;
    font-size: 16px;
    font-weight: 600;
    cursor: pointer;
    transition: background-color 0.3s;
        }

        .login-container button:hover {
            background-color: #666;
        }
    </style>
</head>
<body>
    <div class="login-container">
<!-- reset_request.php -->
<form action="update_password.php" method="post">
    <input type="hidden" name="token" value="<?php echo htmlspecialchars($token); ?>">
    <label for="password">New Password:</label>
    <input type="password" id="password" name="password" required>
    <button type="submit">Reset Password</button>
</form>
    </div>
</body>
</html>
    <?php
     }
    ?>
