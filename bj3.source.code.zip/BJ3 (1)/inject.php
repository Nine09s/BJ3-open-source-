<?php

// ตั้งค่าการเชื่อมต่อฐานข้อมูล
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "bj3";

$conn = new mysqli($servername, $username, $password, $dbname);

// ตรวจสอบการเชื่อมต่อ
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// ฟังก์ชั่นในการอ่านไฟล์ CSV
if (($handle = fopen("2-1-4.csv", "r")) !== FALSE) {
  // อ่านและข้ามบรรทัดหัวข้อ
  fgetcsv($handle, 1000, ",");

  while (($data = fgetcsv($handle, 1000, ",")) !== FALSE) {
      // ตัดคอมม่าท้ายแถวออก
      $data = array_slice($data, 0, 7);

      // ตรวจสอบว่าจำนวนคอลัมน์ถูกต้องหรือไม่
      if (count($data) == 7) {
          $year_class = $data[0];
          $class_number = $data[1];
          $student_number = $data[2];
          $gender = $data[3];
          $first_name = $data[4];
          $last_name = $data[5];
          $score = $data[6];

          // ปรับชื่อคอลัมน์ตามตารางในฐานข้อมูลของคุณ
          $sql = "INSERT INTO students (year_class, class_number, student_number, gender, first_name, last_name, score) 
                  VALUES ('$year_class', '$class_number', '$student_number', '$gender', '$first_name', '$last_name', '$score')";

          if ($conn->query($sql) === FALSE) {
              echo "Error: " . $sql . "<br>" . $conn->error;
          }
      } else {
          echo "Error: Invalid number of columns in CSV row.<br>";
      }
  }
  fclose($handle);
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="th">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>บันทึกความประพฤตินักเรียน</title>
    <style>
        body {
            font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif;
            background-color: #f5f5f7;
            color: #1d1d1f;
            margin: 0;
            padding: 0;
        }
        header {
            background-color: #ffffff;
            padding: 1em 0;
            border-bottom: 1px solid #d2d2d7;
            text-align: center;
        }
        header h1 {
            font-weight: 600;
            font-size: 24px;
            margin: 0;
        }
        main {
            padding: 4em 2em;
            text-align: center;
        }
        main h2 {
            font-weight: 500;
            font-size: 22px;
            margin-bottom: 1em;
            line-height: 1.5;
        }
        main p {
            font-size: 20px;
            color: #6e6e73;
            margin: 1em 0 2em;
        }
        .button-container {
            display: flex;
            justify-content: center;
            gap: 1em;
            flex-direction: column;
        }
        .button-container a {
            display: inline-block;
            background-color: #0071e3;
            color: #ffffff;
            padding: 0.8em 1.6em;
            text-decoration: none;
            border-radius: 24px;
            font-size: 17px;
            font-weight: 600;
            transition: background-color 0.3s;
        }
        .button-container a:hover {
            background-color: #005bb5;
        }
        footer {
            background-color: #f5f5f7;
            padding: 2em 0;
            text-align: center;
            font-size: 14px;
            color: #6e6e73;
            border-top: 1px solid #d2d2d7;
        }

        @media (min-width: 768px) {
            .button-container {
                flex-direction: row;
            }
        }
    </style>
</head>
<body>
    <header>
        <h1>โรงเรียนบรรหารแจ่มใสวิทยา 3</h1>
    </header>
    <main>
        <h2>ยินดีต้อนรับสู่<br>บันทึกความประพฤตินักเรียน</h2>
        <div class="button-container">
            <a href="student_history.html">ประวัติความประพฤติ</a>
            <a href="behavior_report.html">รายงานความประพฤติ</a>
        </div>
    </main>
    <footer>
        <p>&copy; 2024 โรงเรียนของเรา</p>
    </footer>
</body>
</html>