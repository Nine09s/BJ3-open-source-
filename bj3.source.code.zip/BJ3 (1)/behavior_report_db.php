<?php
// เชื่อมต่อฐานข้อมูล
include 'server.php';
session_start();
// รับค่า input จาก URL
$student_id = $_POST['student_id'];
$id_rule = $_POST['_score'];
$other = $_POST["details"];
$teacher_name= $_POST["teacher_name"];
echo " ".$id_rule ."ll";
echo $student_id;
$sql_rule = "SELECT * FROM rule WHERE id = '$id_rule'";
$result_rule = $conn->query($sql_rule);
if($result_rule->num_rows > 0) {
// Output data of the row
$row_rule = $result_rule->fetch_assoc();
echo "oll",$row_rule["_score"];
$score_c = $row_rule["_score"];
$rule = $row_rule["rule"];

// สร้าง SQL query


$target_dir = __DIR__ . "/upload/";
$file_basename = basename($_FILES["fileToUpload"]["name"]);
$file_extension = strtolower(pathinfo($file_basename, PATHINFO_EXTENSION));

// Create a unique name for the file
$new_filename = uniqid() . "." . $file_extension;
$target_file = $target_dir . $new_filename;
$uploadOk = 1;

// Check if image file is an actual image or fake image
if(isset($_POST["submit"])) {
    $check = getimagesize($_FILES["fileToUpload"]["tmp_name"]);
    if($check !== false) {
        echo "File is an image - " . $check["mime"] . ".";
        $uploadOk = 1;
    } else {
        echo "File is not an image.";
        $uploadOk = 0;
    }
}

// Check if file already exists
if (file_exists($target_file)) {
    echo "Sorry, file already exists.";
    $uploadOk = 0;
}

// Check file size (limit to 5MB)
if ($_FILES["fileToUpload"]["size"] > 5000000) {
    echo "Sorry, your file is too large.";
    $uploadOk = 0;
}

// Allow certain file formats
if($file_extension != "jpg" && $file_extension != "png" && $file_extension != "jpeg" && $file_extension != "gif" ) {
    echo "Sorry, only JPG, JPEG, PNG & GIF files are allowed.";
    $uploadOk = 0;
}

// Check if $uploadOk is set to 0 by an error
if ($uploadOk == 0) {
    echo "Sorry, your file was not uploaded.";
// If everything is ok, try to upload file
} else {
    if (move_uploaded_file($_FILES["fileToUpload"]["tmp_name"], $target_file)) {
        echo "The file ". htmlspecialchars($new_filename). " has been uploaded.";

        
        // Insert file information into the database
        $stmt = $conn->prepare("INSERT INTO history (filename, filepath,id_student, score_c , because , other ,teacher_name) VALUES ( '$new_filename', '$target_file','$student_id' , '$score_c','$rule','$other'  ,'$teacher_name')");
        if ($stmt->execute()) {
            echo "File information saved to database.";
        } else {
            echo "Error: " . $stmt->error;
        }
        $stmt->close();
    } else {
        echo "Sorry, there was an error uploading your file.";
    }

}
$sql_sel = "SELECT score FROM students WHERE student_number = '$student_id'";
$result_sel = $conn->query($sql_sel);
if($result_sel->num_rows > 0) {
// Output data of the row
$row_sel = $result_sel->fetch_assoc();
echo $row_sel["score"];
$score_update = $row_sel["score"] + $score_c;
$_SESSION["REPORT_SUSESSFULL"] = 1;
} else {
echo "O results";
}


$sql_update = "UPDATE `students` SET score = '$score_update' 
WHERE student_number = '$student_id'  ";
$result_update = $conn->query($sql_update);

header ("Location: behavior_report.php");
#jjj---------
}
?>