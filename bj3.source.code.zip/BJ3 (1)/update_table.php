<?php
    include 'server.php';
    $student_number=$_POST["student_number"];
    $class_number=$_POST["class_number"];
    $first_name=$_POST["first_name"];
    $last_name=$_POST["last_name"];
    $score=$_POST["score"];

    $sql = "UPDATE students 
SET first_name = '$first_name',  last_name = '$last_name',  class_number = '$class_number', score = '$score' WHERE student_number = '$student_number';";

    if ($conn->query($sql) === TRUE) {
        echo "updated pasword successfully";
    } else {
        echo "Error updating record: " . $conn->error;
    }
    
    // Close database connection
    $conn->close();
    
header ("Location: student_history.php")
?>