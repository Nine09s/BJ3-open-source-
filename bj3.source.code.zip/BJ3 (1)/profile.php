<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Profile</title>
    <style>
        body {
            font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif;
            line-height: 1.6;
            background-color: #f5f5f7;
            color: #333;
        }
        .container {
            max-width: 600px;
            margin: 0 auto;
        }
        .profile, .payment-history {
            border: 1px solid #e1e1e1;
            border-radius: 10px;
            padding: 30px;
            background-color: #fff;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            margin-bottom: 20px;
        }
        .profile h2, .payment-history h2 {
            margin-bottom: 20px;
            font-size: 24px;
            color: #1d1d1f;
            border-bottom: 2px solid #e1e1e1;
            padding-bottom: 10px;
        }
        .profile p {
            margin: 10px 0;
    font-size: 18px;
    display: flex;
    justify-content: space-between;
    flex-direction: row;
        }
        .profile p strong {
            font-weight: 600;
            color: #000;
            flex-basis: 40%;
        }
        .profile p span {
            flex-basis: 60%;
            text-align: right;
        }
        .payment-history table {
            width: 100%;
            border-collapse: collapse;
        }
        .payment-history table, .payment-history th, .payment-history td {
            border: 1px solid #e1e1e1;
        }
        .payment-history th, .payment-history td {
            padding: 10px;
            text-align: left;
            white-space: nowrap;
        }
        .payment-history th {
            background-color: #f5f5f7;
        }
        .table-container {
            overflow-x: auto;
        }
        .back-button {
            display: block;
            margin: 20px 0;
            padding: 10px 20px;
            background-color: #000;
            color: #fff;
            text-align: center;
            border-radius: 5px;
            text-decoration: none;
        }
        .back-button:hover {
            background-color: #999;
        }
        @media (max-width: 600px) {
            .profile p {
                font-size: 16px;
            }
            .profile p strong, .profile p span {
                flex-basis: 100%;
                text-align: left;
            }
            .profile p span {
                text-align: right;
            }
            .profile, .payment-history {
                padding: 15px;
            }
        }
    </style>
</head>
<body>
    
    <div class="container">
    <a href="student_history.php" class="back-button">ย้อนกลับ</a>
        <?php
        include 'server.php';
        $student_id = $_POST["student_id"];
        $sql_sel = "SELECT * FROM students WHERE student_number = '$student_id'";
        $result_sel = $conn->query($sql_sel);
        if ($result_sel->num_rows > 0) {
            $row_sel = $result_sel->fetch_assoc();
        ?>
        <div class="profile">
            <h2>User Profile</h2>
            <?php
            echo "<p><strong>ชื่อ:</strong> <span>" . $row_sel["gender"] . " " . $row_sel["first_name"] . " " . $row_sel["last_name"] . "</span></p>";
            echo "<p><strong>ชั้น:</strong> <span>" . $row_sel["year_class"] . "</span></p>";
            echo "<p><strong>เลขที่:</strong> <span>" . $row_sel["class_number"] . "</span></p>";
            echo "<p><strong>รหัสนักเรียน:</strong> <span>" . $row_sel["student_number"] . "</span></p>";
            echo "<p><strong>คะแนนความประพฤติ:</strong> <span>" . $row_sel["score"] . "</span></p>";
            ?>
        </div>
        <?php 
        }

        $sql_payments = "SELECT * FROM history WHERE id_student = '$student_id'";
        $result_payments = $conn->query($sql_payments);
        ?>
        <div class="payment-history">
            <h2>ประวัติความประพฤติ</h2>
            <div class="table-container">
                <?php
                if ($result_payments->num_rows > 0) {
                    echo "<table>";
                    echo "<tr><th>เวลา</th><th>ผู้รายงาน</th><th>หมายเหตุ</th><th>คะแนน</th><th>รูป</th></tr>";
                    while ($row_payments = $result_payments->fetch_assoc()) {
                        echo "<tr>";
                        echo "<td><p>" . $row_payments["time"] . "</p></td>";
                        echo "<td>" . $row_payments["teacher_name"] . "</td>";
                        echo "<td>" . $row_payments["because"] . ": <br>" . $row_payments["other"] . "</td>";
                        echo "<td>" . $row_payments["score_c"] . "</td>";
                        echo "<td><img src='upload/".$row_payments["filename"]."' style='width:200px; height:auto;' alt='img'></td>";

                        echo "</tr>";
                    }
                    echo "</table>";
                } else {
                    echo "<p>ไม่พบประวัติการกระทำความผิด</p>";
                }
                ?>
            </div>
        </div>
        <?php 
        $conn->close();
        ?>
     </div>
</body>
</html>