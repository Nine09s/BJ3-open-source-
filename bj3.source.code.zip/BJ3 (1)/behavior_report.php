<?php

ini_set('display_errors', 0);
session_start();

if(isset($_SESSION['user'])){
    if($_SESSION['user_level'] == "admin"){

include 'server.php';

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Student Behavior Form</title>
    <style>
        * {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif;
        }

        body {
            display: flex;
            flex-direction: column;
            justify-content: flex-start;
            align-items: center;
            min-height: 100vh;
            background-color: #f5f5f7;
        }

        .tab-container {
            display: flex;
    border-radius: 20px;
    width: 100%;
    /* max-width: 500px; */
    /* align-items: center; */
    align-content: space-between;
    justify-content: space-between;
    flex-wrap: nowrap;
    margin-top: 10px;
    flex-direction: row;
        }
        
        .profile{
            width: 100%;
    display: flex;
    /* padding: 10px 20px; */
    text-align: center;

   
    text-decoration: none;
    color: #333;
    flex-direction: column;
    align-content: center;
    align-items: center;}
    a{
        text-decoration: none;
        color:#000;
    }
        .tab {
            width: 100%;
            
            padding: 10px 20px;
            text-align: center;
            cursor: pointer;
            border: 1px solid #ccc;
            border-bottom: none;
            border-radius: 20px;
            background-color: #f2f2f2;
            text-decoration: none;
            color: #333;
        }

        .tab_active {
            width: 100%;
    padding: 10px;
    border-radius: 20px;
    background-color: #fff;
    color: #000;
    font-size: 16px;
    cursor: pointer;
   
        }

        .container {
            background: #ffffff;
            padding: 20px 30px;
            border-radius: 12px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            max-width: 500px;
            width: 100%;
        }

        .form-group {
            margin-bottom: 15px;
        }
     

        select option {
            white-space: pre-wrap; /* Allow new lines in option */
        }

        label {
            display: block;
            margin-bottom: 5px;
            color: #555555;
        }

        input, select, textarea {
            width: 100%;
            padding: 10px;
            border: 1px solid #dddddd;
            border-radius: 8px;
            font-size: 16px;
            color: #333333;
        }

        input:focus, select:focus, textarea:focus {
          
            outline: none;
        }

        button {
            width: 100%;
            
           
            border-radius: 8px;
            background-color: #000;
            color: #ffffff;
            font-size: 16px;
            cursor: pointer;
           
        }

        button:hover {
            background-color: #999;
        }
        .profile_user{
            
            padding-left:10px;
            padding-right:10px;
            width: 100%;
    display: flex;
    flex-direction: row;
    align-items: center;
    align-content: center;
    justify-content: space-between;

        }.logout{
            width: 200px;

        }
        .tab-alin{
            display: flex;
    align-items: center;
    width: 100%;
    max-width:500px;
    padding: 10px;
    flex-direction: column;
     border-radius: 20px;
    border: 1px solid #ccc;
    border-bottom: none;
    background-color: #f2f2f2;

        }
    </style>


</head>
<body>
<div class="profile">
    <div class="tab-alin">
    <div class=profile_user>
    <?php
    echo "<a href='teacher_profile.php'>".$_SESSION['user']."</a>";
    ?><button style=" background:#fff; padding:2px;width:100px;border-radius: 20px;"><a href="logout.php">logout</a></button>
    </div>
<div class="tab-container">
    
    <button class="tab_active"><a href="behavior_report.php" >ฟอร์มนักเรียน</a></button>
    <button class="tab"><a href="student_history.php">กรองนักเรียนตามห้อง</a></button>
    </div></div></div>

<div class="container">
    <?php
    
if($_SESSION["REPORT_SUSESSFULL"] == 1){
    echo '<p style="color: green; width:100%; text-align: center;">[ upload successfull ]</p>';

}

$_SESSION["REPORT_SUSESSFULL"] = 0;
    ?>
    <h2 style='text-align: center; margin:5px;  margin-bottom:15px;'>Student Behavior Form</h2>
    <form action="behavior_report_db.php" method="post" enctype="multipart/form-data">
   
            
            <?php
            echo "<input  value='".$_SESSION['user']."' type='hidden' id='teacher_name' name='teacher_name' required>";
     ?>

        <div class="form-group">
        <label for="room">เลือกปีการศึกษา:</label> 
        <select id="grade" name="grade" onchange="updateRooms()">
             <?php


// Example session value for demonstration
// You can change this to test different values

// Function to get the grade and the number of rooms
function getGradeAndRooms($post_year) {
    // Extract the grade level (e.g., ม.1 from ม.1/1)
    $grade = explode("/", $post_year)[0];

    // Determine the number of rooms based on the grade level
    if (in_array($grade, ["ม.1", "ม.2", "ม.3"])) {
       
    } elseif (in_array($grade, ["ม.4", "ม.5", "ม.6"])) {
        
    } else {
        return "Invalid grade level.";
        echo $_SESSION['POS_year'];
    }

    // Output the grade and number of rooms
    return  $grade;
}

// Call the function and echo the result
echo getGradeAndRooms($_SESSION['POS_year']);


            if($_SESSION['POS_year'] != 0){
                echo "<option value=''>".getGradeAndRooms($_SESSION['POS_year'])."</option>";
                 
            }else{
                ?> 
                 <option value="">เลือกปีการศึกษา</option>
                <?php
            }
            ?>
            <option value="ม.1">ม.1</option>
            <option value="ม.2">ม.2</option>
            <option value="ม.3">ม.3</option>
            <option value="ม.4">ม.4</option>
            <option value="ม.5">ม.5</option>
            <option value="ม.6">ม.6</option>
            </div>
        </select>


        <div class="form-group">
        <label for="room">ห้อง:</label>
        <select id="year_class" name="year_class" onchange="filterclass()">
            <?php
             if($_SESSION['POS_year'] != 0){
                echo "<option value=''>".$_SESSION['POS_year']."</option>";
                 
            }else{
                ?> 
                <option value="">เลือกห้อง</option>
                <?php
            }
            ?>
            
        </select>
        
        </div>

        <div class="form-group">
            <?php
            ?>
            <label for="student_id">Student ID</label>
    <select id="student_id" name="student_id" required>
        <option value="">Select Student ID</option>
        <?php
        if (isset($_SESSION['filtered_students'])) {
            $filtered_students = $_SESSION['filtered_students'];
            foreach ($filtered_students as $student) {
                $option_text = "(" . $student["score"] . ") no." . $student['class_number'] . " " . $student['student_number'] . "\n";
                if($student['gender'] == "เด็กชาย"){
                    $option_text .= " ด.ช.";
                } else if ($student['gender'] == "เด็กหญิง"){
                    $option_text .= " ด.ญ.";
                }
                $option_text .= " " . $student['first_name'] . " " . $student['last_name'];

                // Replace new line characters with HTML line break entity
                $option_text = str_replace("\n", "&#10;", htmlspecialchars($option_text));
                echo "<option value='". $student['student_number'] ."'>$option_text</option>";
            }
        }
        ?>
    </select>
        <div class="form-group">
            <label for="image">Image</label>
            <input type="file" id="image" name="fileToUpload" accept="image/*" required>
        </div>

        <div class="form-group">
            <label for="misconduct">Misconduct</label>
            <select id="misconduct" name="_score" required>
                <?php

                $result_rule = $conn->query("SELECT * FROM rule");
                while ($row_rule = $result_rule->fetch_assoc()) {
                    if ($row_rule['_score'] == 0){
                        echo "<optgroup label='".$row_rule['rule']."'>";
                    }else{
                    echo "<option value='".$row_rule['id']."'>";
                    echo "(".$row_rule['_score'].") ". $row_rule['rule'] ;
                }}
                ?>
            </select>
        </div>

        <div class="form-group">
            <label for="details">Details</label>
            <textarea id="details" name="details" rows="4" required></textarea>
        </div>

        <button type="submit" style="padding: 10px;margin-top: 10px;" >Submit</button>
    </form>
</div>

<script>
    function filterclass() {
        var year_class = document.getElementById('year_class').value;
        var year_class = document.getElementById('year_class').value;

        var xhr = new XMLHttpRequest();
        xhr.open("POST", "filter_db.php", true);
        xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
        xhr.onreadystatechange = function() {
            if (xhr.readyState == 4 && xhr.status == 200) {
                // รีโหลดหน้าเพื่อตัวเลือกนักเรียนที่ถูกกรองใหม่
                location.reload();
            }
        };
        xhr.send("year_class=" + year_class);
         }

        // ข้อมูลห้องเรียนสำหรับแต่ละเกรด
        const gradeRooms = {
            
            'ม.1': Array.from({ length: 15 }, (_, i) => `ม.1/${i + 1}`),
            'ม.2': Array.from({ length: 15 }, (_, i) => `ม.2/${i + 1}`),
            'ม.3': Array.from({ length: 15 }, (_, i) => `ม.3/${i + 1}`),
            'ม.4': Array.from({ length: 10 }, (_, i) => `ม.4/${i + 1}`),
            'ม.5': Array.from({ length: 10 }, (_, i) => `ม.5/${i + 1}`),
            'ม.6': Array.from({ length: 10 }, (_, i) => `ม.6/${i + 1}`)
        };

        // ฟังก์ชันอัปเดต dropdown ห้องเรียน
        function updateRooms() {
            var grade = document.getElementById("grade").value;
            var roomSelect = document.getElementById("year_class");
            roomSelect.innerHTML = '';

            if (grade && gradeRooms[grade]) {
                gradeRooms[grade].forEach(room => {
                    var option = document.createElement("option");
                    option.value = room;
                    option.text = room;
                    roomSelect.appendChild(option);
                });
            }
        }
       
</script>

</body>
</html>
<?php

    }else{
        header ("Location: student_history.php");
    }
$_SESSION['POS_year'] = 0;

    }else{
        header ("Location: login.php");
    }

?>