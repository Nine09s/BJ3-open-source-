<?php
session_start();

// ตั้งค่าการเชื่อมต่อฐานข้อมูล
include 'server.php';


$_SESSION['Invalid'] = "";
// รับค่าจากฟอร์ม
$user = $_POST['username'] ?? null;
$pass = $_POST['password'] ?? null;

if ($user === null || $pass === null) {
    echo "Username or password is missing.";
    exit;
}

// เตรียมคำสั่ง SQL โดยใช้ prepared statements
$stmt = $conn->prepare("SELECT * FROM teacher WHERE email = ? AND password = ?");
$stmt->bind_param("ss", $user, $pass); // 'ss' หมายถึงค่าทั้งสองเป็น string

// รันคำสั่ง SQL
$stmt->execute();
$result = $stmt->get_result();
$user = $result->fetch_assoc();

if ($user) {
    // ถ้าพบผู้ใช้ให้เข้าสู่ระบบสำเร็จ
    $_SESSION['user'] = $user['user'];
    $_SESSION['email'] = $user['email'];
    $_SESSION['user_level'] = $user['user_level'];

    echo "Login successful!";
    header("Location: behavior_report.php");
    exit;
} else {
    // ถ้าไม่พบผู้ใช้ให้แสดงข้อความผิดพลาด

    $_SESSION['Invalid'] = "Invalid username or password";
    header("Location: login.php");
}

// ปิดการเชื่อมต่อ
$stmt->close();
$conn->close();
?>