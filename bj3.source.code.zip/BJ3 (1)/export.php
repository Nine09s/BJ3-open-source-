<?php
// Include the database connection file
include('server.php');

// Define the query
$query = "SELECT * FROM students";

// Execute the query
if ($result = $conn->query($query)) {

    // Open a file in write mode
    $file_path = 'download/student.csv'; // Ensure this path is web-accessible
    $file = fopen($file_path, 'w');

    // Fetch the column names
    $fields = $result->fetch_fields();
    $headers = array();
    foreach ($fields as $field) {
        $headers[] = $field->name;
    }

    // Write column headers to the CSV file
    fputcsv($file, $headers);

    // Write rows to the CSV file
    while ($row = $result->fetch_assoc()) {
        fputcsv($file, $row);
    }

    // Close the file
    fclose($file);

    // Free the result set
    $result->free();
}

// Close the connection
$conn->close();
header ("Location: download/student.csv");
header ("Location: teacher_profile.php");

?>