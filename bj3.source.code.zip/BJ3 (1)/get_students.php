<?php
// Include database connection or any necessary files
include 'server.php';

// Check if year/class parameter is provided
if (isset($_GET['year_class'])) {
    $year_class = $_GET['year_class'];

    // Prepare SQL query to fetch students based on year/class
    $sql = "SELECT * FROM students WHERE `year/class` = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param('s', $year_class);
    $stmt->execute();
    $result = $stmt->get_result();

    // Fetch results into an array
    $students = [];
    while ($row = $result->fetch_assoc()) {
        $students[] = $row;
    }

    // Output JSON encoded array of students
    echo json_encode($students);
} else {
    // If year/class parameter is not provided, return an error message or handle accordingly
    echo json_encode(['error' => 'Year/class parameter is required']);
}
?>