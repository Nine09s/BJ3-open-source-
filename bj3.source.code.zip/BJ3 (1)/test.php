<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Profile Tab</title>
    <style>
        body {
            margin: 0;
            padding: 0;
            font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif;
        }

        .header {
            position: fixed;
            top: 0;
            width: 100%;
            background-color: #0071e3;
            color: #ffffff;
            padding: 10px 0;
            text-align: center;
            z-index: 1000;
            transition: top 0.3s;
        }

        .content {
            padding: 60px 20px;
        }

        .profile-info {
            margin: 20px 0;
            padding: 20px;
            background-color: #f5f5f7;
            border-radius: 10px;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
        }

        .profile-info h2 {
            margin: 0;
        }
    </style>
</head>
<body>
    <div class="header" id="header">
        <div class="profile-info">
            <h2>Username: John Doe</h2>
            <p>Email: john.doe@example.com</p>
            <p>Account created at: 2023-01-01</p>
        </div>
    </div>

    <div class="content">
        <h1>Content Section</h1>
        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Suspendisse varius enim in eros elementum tristique. Duis cursus, mi quis viverra ornare, eros dolor interdum nulla, ut commodo diam libero vitae erat. Aenean faucibus nibh et justo cursus id rutrum lorem imperdiet. Nunc ut sem vitae risus tristique posuere.</p>
        <!-- Add more content here to make the page scrollable -->
    </div>

    <script>
        // Add JavaScript if needed for additional functionality
    </script>
</body>
</html>